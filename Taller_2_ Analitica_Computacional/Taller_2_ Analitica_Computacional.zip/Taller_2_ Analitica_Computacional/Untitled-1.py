print("Hola Mundo")

variable = 12


suma = variable +1
suma2=variable +2
print(variable)

2+2
