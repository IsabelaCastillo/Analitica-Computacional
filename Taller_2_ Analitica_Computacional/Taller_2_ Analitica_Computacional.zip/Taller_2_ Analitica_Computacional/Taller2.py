Hola = 5
Carlos= 12
IS=2121
print("Hola Carlitos")